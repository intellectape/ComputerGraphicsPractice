# prog2
helper files for the intro cg class's second programming assignment
